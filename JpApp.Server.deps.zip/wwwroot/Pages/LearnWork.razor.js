﻿export function buttonPick() {
    const buttonClick = document.querySelector('.title__box');
    buttonClick.classList.toggle('active');
}